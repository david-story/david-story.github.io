---
layout: pages
title:  "Python Resources"
minimal_mistakes_skin    : "dark"
---

This is the page for Python Resources