---
layout: pages2
title:  "About"
minimal_mistakes_skin    : "dark"
author_profile: true
---

Meadowview lab is my mini "lab" of my work and ideas.
If you want to know more about my background you can download my resume and curriculum vitae below:

<ul style="list-style-type:square">
<li><a href="/assets/documents/DavidStoryResume-Public.pdf">Resume</a></li>
<li><a href="/assets/documents/DavidStoryCV-Public.pdf">Curriculum Vitae</a></li>
</ul>

In my free time, I like to image galaxies, nebulas, and other cool space features. These can be found on my flickr:


<a data-flickr-embed="true"  href="https://www.flickr.com/photos/166289283@N04/albums/72157676053093258" title="Astrophotography"><img src="https://farm5.staticflickr.com/4882/45323185104_72b3d14530_b.jpg" width="1024" height="682" alt="Astrophotography"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>