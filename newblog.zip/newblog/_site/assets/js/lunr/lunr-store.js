var store = [{
        "title": "Letter to the Internet",
        "excerpt":"Greetings, Internet! Hello readers of the Internet! I am creating this post just as a formal welcome to my page, as well as testing if this Jekyll static page creation really works! What you should be able to expect from this site is to be an open-source of information and...","categories": [],
        "tags": [],
        "url": "http://localhost:4000/Letter-to-the-reader/",
        "teaser":null}]
